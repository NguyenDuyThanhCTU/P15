import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDnLnqnnOCOqcFFqIVaptbknuuKqgGfxyU",

  authDomain: "taphoa-605ab.firebaseapp.com",

  projectId: "taphoa-605ab",

  storageBucket: "taphoa-605ab.appspot.com",

  messagingSenderId: "11117929919",

  appId: "1:11117929919:web:97e535d3eea19fd9c4ed0a",

  measurementId: "G-1KXEEY1NTD",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
// export const db = getFirestore(app);

export const auth = getAuth(app);
