import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBhAI058pBxgUYqoSLff5-l-1q-co9UbXA",

  authDomain: "asiachau-2b968.firebaseapp.com",

  projectId: "asiachau-2b968",

  storageBucket: "asiachau-2b968.appspot.com",

  messagingSenderId: "53165824863",

  appId: "1:53165824863:web:860687fd3f7eecf93f34ea",

  measurementId: "G-8EGXRGRJTL",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
// export const db = getFirestore(app);

export const auth = getAuth(app);
