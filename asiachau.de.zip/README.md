Tên Công Ty : ASIA ACHAU UG ( haftungsbeschränkt )
Tên công ty : ASIA Á CHÂU UG
Địa chỉ : Merzdorfer Bahnhof Straße 33 - 03042 - Cottbus
sdt : +49 174 822 1234
email : achaucottbus@gmail.com
