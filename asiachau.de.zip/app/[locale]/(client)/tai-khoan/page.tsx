import Account from "@components/client/Account/Account";
import React from "react";

const AccountPage = () => {
  return (
    <div>
      <Account />
    </div>
  );
};

export default AccountPage;
