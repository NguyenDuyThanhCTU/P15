import Cart from "@components/client/Cart/Cart";
import React from "react";

const CartPage = () => {
  return (
    <div>
      <Cart />
    </div>
  );
};

export default CartPage;
