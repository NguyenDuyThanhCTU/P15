import Order from "@components/client/Order/Order";

import React from "react";

const OrderPage = () => {
  return (
    <>
      <Order />
    </>
  );
};

export default OrderPage;
